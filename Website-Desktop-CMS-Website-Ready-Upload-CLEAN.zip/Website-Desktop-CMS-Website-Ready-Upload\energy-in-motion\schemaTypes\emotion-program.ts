export default {
  name: 'emotionProgram',
  title: 'E-Motion Program',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Title',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'description',
      title: 'Description',
      type: 'text',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'whoItsFor',
      title: "Who It's For",
      type: 'text',
    },
    {
      name: 'purpose',
      title: 'Purpose',
      type: 'text',
    },
    {
      name: 'innerFocus',
      title: 'Inner Focus',
      type: 'text',
    },
    {
      name: 'otherFocus',
      title: 'Other Focus',
      type: 'text',
    },
    {
      name: 'outerFocus',
      title: 'Outer Focus',
      type: 'text',
    },
    {
      name: 'programHighlights',
      title: 'Program Highlights',
      type: 'object',
      fields: [
        {
          name: 'level1',
          title: 'Level 1',
          type: 'object',
          fields: [
            {
              name: 'title',
              title: 'Title',
              type: 'string',
            },
            {
              name: 'description',
              title: 'Description',
              type: 'text',
            },
          ],
        },
        {
          name: 'level2',
          title: 'Level 2',
          type: 'object',
          fields: [
            {
              name: 'title',
              title: 'Title',
              type: 'string',
            },
            {
              name: 'description',
              title: 'Description',
              type: 'text',
            },
          ],
        },
      ],
    },
    {
      name: 'keyBenefits',
      title: 'Key Benefits',
      type: 'array',
      of: [{type: 'string'}],
    },
    {
      name: 'category',
      title: 'Category',
      type: 'string',
      options: {
        list: [
          {title: 'E-Motions', value: 'E-Motions'},
          {title: 'E-Motion - Emotional Intelligence', value: 'E-Motion - Emotional Intelligence'},
          {title: 'E-Motion - Self-Awareness', value: 'E-Motion - Self-Awareness'},
          {title: 'E-Motion - Empathy', value: 'E-Motion - Empathy'},
          {title: 'E-Motion - Mindfulness', value: 'E-Motion - Mindfulness'},
          {title: 'E-Motion - Stress Management', value: 'E-Motion - Stress Management'},
          {title: 'E-Motion - Personal Growth', value: 'E-Motion - Personal Growth'},
          {title: 'E-Motion - Healing', value: 'E-Motion - Healing'},
          {title: 'E-Motion - Relationships', value: 'E-Motion - Relationships'},
        ],
      },
    },
    {
      name: 'featured',
      title: 'Featured',
      type: 'boolean',
      initialValue: false,
    },
    {
      name: 'publishedAt',
      title: 'Published At',
      type: 'datetime',
      initialValue: () => new Date().toISOString(),
    },
    {
      name: 'heroImage',
      title: 'Hero Image',
      type: 'image',
      options: {
        hotspot: true,
      },
    },
    {
      name: 'displayBoxPhoto',
      title: 'Display Box Photo',
      type: 'boolean',
      description: 'Show/hide the program image on the detail page',
      initialValue: true,
    },
  ],
  preview: {
    select: {
      title: 'title',
      category: 'category',
      media: 'heroImage',
    },
    prepare(selection: any) {
      const {title, category} = selection
      return {
        title,
        subtitle: category,
      }
    },
  },
}
